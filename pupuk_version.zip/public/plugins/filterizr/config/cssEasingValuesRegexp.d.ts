/**
 * A Regexp to validate potential values for the CSS easing property of transitions.
 */
export declare const cssEasingValuesRegexp: RegExp;
